within NonInteractingTanks;

connector FlowConnect
  Real h;
  flow Real F;
end FlowConnect;
